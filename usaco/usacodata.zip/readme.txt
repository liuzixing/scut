usaco testdata

provided by felicia